library(shiny)
library(shinythemes)
library(shinydashboard)
library(dplyr)
library(OpenImageR)
library(rsconnect)
library(ggplot2)

Laptop <- read.csv("df11.csv", header = TRUE, encoding="UTF-8", stringsAsFactors=FALSE)
EDA_Laptop <- select(Laptop, Company, TypeName, OpSys, Price.Filter, Purpose.Filter, Time.Filter, ScreenSize.Filter)


ui <- dashboardPage(skin = "purple",
                    dashboardHeader(title = "EasyPC",titleWidth = 350),
                    sidebar <- dashboardSidebar(
                        width=350, 
                        sidebarMenu(
                            menuItem("Introduction", icon = icon("refresh"), tabName = "Introduction",
                                     badgeColor = "green"),
                            menuItem("Selection", tabName = "selection", icon = icon("dashboard"),badgeLabel = "HIT!"),
                            menuItem("EDA", icon = icon("database"), tabName = "EDA",
                                     badgeColor = "green"),
                            menuItem("Presentation Slides", icon = icon("file-code-o"), 
                                     href = "https://rpubs.com/Soong_Woei_Meng/715870")
                        )
                    ),
                    body <- dashboardBody(
                        
                        tabItems(
                            tabItem(tabName="Introduction",
                                    img(src='https://i.ibb.co/ZHdzmKt/4.jpg', align = "absolute")),
                            
                            tabItem(tabName="selection",
                                    
                                    fluidPage(
                                        sidebarLayout(
                                            mainPanel(
                                                sliderInput("PriceInput", "What is your budget?",min=0,max=6000,value=c(2000,3500),  width = "100%"),
                                                radioButtons("PurposeInput", "For what purpose is the laptop for?", choices = unique(Laptop$Purpose.Filter)),
                                                radioButtons("TimeInput", "How often you carry your laptop around?",choices = unique(Laptop$Time.Filter)),
                                                radioButtons("OSInput", "What operating system you want your laptop to run in?",choices = unique(Laptop$OS.Filter), selected = "Windows", width = "100%")
                                            ),
                                            dataTableOutput("LaptopRecom")
                                        )
                                    )
                            ),
                            tabItem(tabName = "EDA", 
                                    varSelectInput("group", "Frequency chart by", EDA_Laptop), 
                                    plotOutput("plot"))
                        )))

server <- function(input, output) {
    filtered <- reactive({
        Laptop %>%
            filter(Price_RM <= max(input$PriceInput)
            ) %>%
            filter(Price_RM > min(input$PriceInput)
            ) %>%
            filter(Purpose.Filter == input$PurposeInput
            ) %>%
            filter(Time.Filter == input$TimeInput
            ) %>%
            filter(OS.Filter == input$OSInput
            ) %>%
            select(Company, Product, TypeName, Screen_Inches, Cpu, Gpu, Weight_KG, Ram_GB, Memory_GB, Price_RM
            )
    })
    
    output$LaptopRecom <- renderDataTable({
        filtered()
    })
    
    output$plot <- renderPlot({
        ggplot(EDA_Laptop, aes(!!input$group)) +
            geom_bar(fill = "#0073C2FF") })
    
    
}

shinyApp(ui, server)
